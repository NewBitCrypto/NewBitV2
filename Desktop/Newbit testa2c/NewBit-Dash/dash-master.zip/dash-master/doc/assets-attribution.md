The list of assets used in the Dash Core source and their attribution can now be found in [contrib/debian/copyright](../contrib/debian/copyright).
