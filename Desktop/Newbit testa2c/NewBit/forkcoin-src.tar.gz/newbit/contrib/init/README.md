Sample configuration files for:
```
SystemD: newbitd.service
Upstart: newbitd.conf
OpenRC:  newbitd.openrc
         newbitd.openrcconf
CentOS:  newbitd.init
OS X:    org.newbit.newbitd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
